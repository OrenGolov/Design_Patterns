module ObserverExercise {
}