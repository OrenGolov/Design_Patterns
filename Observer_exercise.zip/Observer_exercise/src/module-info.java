module Observer_exercise {
}