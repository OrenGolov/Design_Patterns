package Observer_exercise;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

interface RatLifecycleListener {
    void ratEntered(Rat rat);
    void ratExited(Rat rat);
    void ratDied(Rat rat);
}

class Game {
    private List<Rat> rats = new ArrayList<>();
    private List<RatLifecycleListener> listeners = new ArrayList<>();

    public void addRat(Rat rat) {
        rats.add(rat);
        notifyRatEntered(rat);
    }

    public void removeRat(Rat rat) {
        rats.remove(rat);
        notifyRatExited(rat);
    }

    private void notifyRatEntered(Rat rat) {
        for (RatLifecycleListener listener : listeners) {
            listener.ratEntered(rat);
        }
    }

    private void notifyRatExited(Rat rat) {
        for (RatLifecycleListener listener : listeners) {
            listener.ratExited(rat);
        }
    }

    public void notifyRatDied(Rat rat) {
        for (RatLifecycleListener listener : listeners) {
            listener.ratDied(rat);
        }
    }

    public void addRatLifecycleListener(RatLifecycleListener listener) {
        listeners.add(listener);
    }

    public void removeRatLifecycleListener(RatLifecycleListener listener) {
        listeners.remove(listener);
    }
}

class Rat implements Closeable {
    private Game game;
    public int attack = 1;

    public Rat(Game game) {
        this.game = game;
        game.addRat(this);
    }

    @Override
    public void close() throws IOException {
        game.notifyRatDied(this);
        game.removeRat(this);
    }
}

class RatCountObserver implements RatLifecycleListener {
    private int ratCount;

    @Override
    public void ratEntered(Rat rat) {
        ratCount++;
        System.out.println("Rat entered. Total rats: " + ratCount);
    }

    @Override
    public void ratExited(Rat rat) {
        ratCount--;
        System.out.println("Rat exited. Total rats: " + ratCount);
    }

    @Override
    public void ratDied(Rat rat) {
        ratCount--;
        System.out.println("Rat died. Total rats: " + ratCount);
    }
}

public class ObserverExercise {
    public static void main(String[] args) {
        Game game = new Game();
        RatCountObserver ratCountObserver = new RatCountObserver();
        game.addRatLifecycleListener(ratCountObserver);

        Rat rat1 = new Rat(game);
        Rat rat2 = new Rat(game);

        try {
            rat1.close();
            rat2.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}