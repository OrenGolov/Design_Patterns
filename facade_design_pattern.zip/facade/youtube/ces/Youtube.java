package facade.youtube.ces;

public class Youtube {

	public static byte[] getMovieBytes(String url) {
		return url.getBytes();
	}

}
