package facade.youtube.ces;

public interface YoutubeDownloader {
	public MP3 getMP3(String url);
}
