package facade.youtube.ce;

public class Youtube {

	public static byte[] getMovieBytes(String url) {
		return url.getBytes();
	}

}
