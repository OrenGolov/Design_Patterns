package shape.composite;

public class Main {

	public static void main(String[] args) {
		Circle circle = new Circle();
		circle.draw();

		Shapes shapes = new Shapes();
		shapes.add(new Square(), 0);
		shapes.add(new Rectangle(), 1);
		shapes.add(new Circle(), 2);
		
		
		
		Shapes shapes2 = new Shapes();
		shapes2.add(shapes, 0);
		shapes2.add(new Rectangle(), 1);
		
		shapes2.draw();

//		greenSquare.draw();
	}

}
