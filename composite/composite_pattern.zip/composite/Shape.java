package shape.composite;

public abstract class Shape implements Drawable {

}
