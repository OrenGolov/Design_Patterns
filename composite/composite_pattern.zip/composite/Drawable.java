package shape.composite;

public interface Drawable {
	void draw();
}
