package shape.composite;

public class Shapes implements Drawable{

	private Drawable[] shapes = new Drawable[10];

	@Override
	public void draw() {
		for (int i = 0; i < shapes.length; i++) {
			if(shapes[i] != null)
				shapes[i].draw();
		}
	}

	public void add(Drawable drawable, int index) {
		shapes[index] = drawable;
	}
	
	public void remove(int index) {
		shapes[index] = null;
	}

}
