package shape.composite;

public class Square extends Shape {

	@Override
	public void draw() {
		System.out.println("Drawing square...");
	}

}
