package abc.composite;

public class Main {

	public static void main(String[] args) {
		Word i = new Word();
		i.add(new Letter('I'), 0);
		
		Word like = new Word();
		like.add(new Letter('L'), 0);
		like.add(new Letter('i'), 1);
		like.add(new Letter('k'), 2);
		like.add(new Letter('e'), 3);
		
		Word java = new Word();
		java.add(new Letter('J'), 0);
		java.add(new Letter('a'), 1);
		java.add(new Letter('v'), 2);
		java.add(new Letter('a'), 3);
		
		Sentence s = new Sentence();
		s.add(i, 0);
		s.add(like, 1);
		s.add(java, 2);

		s.write();
		
		
		
	}

}
