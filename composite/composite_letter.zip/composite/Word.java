package abc.composite;

import java.util.Arrays;

public class Word implements TypeWriter {
	private Letter[] values = new Letter[10];

	public void add(Letter letter, int index) {
		values[index] = letter;
	}

	public void remove(int index) {
		values[index] = null;
	}



	@Override
	public void write() {
		for (int i = 0; i < values.length; i++) {
			if (values[i] != null)
				values[i].write();
		}
	}

}
