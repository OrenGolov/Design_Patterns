package abc.composite;

public class Letter implements TypeWriter{
	private char value;

	public Letter(char value) {
		this.value = value;
	}

	public char getValue() {
		return value;
	}

	public void setValue(char value) {
		this.value = value;
	}



	@Override
	public void write() {
		System.out.print(value);		
	}

}
