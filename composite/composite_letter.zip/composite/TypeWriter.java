package abc.composite;

public interface TypeWriter {
	public void write(); 
}
