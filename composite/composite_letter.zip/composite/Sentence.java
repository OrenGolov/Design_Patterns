package abc.composite;

public class Sentence implements TypeWriter {
	private Word[] values = new Word[10];

	public void add(Word word, int index) {
		values[index] = word;
	}

	public void remove(int index) {
		values[index] = null;
	}

	@Override
	public void write() {
		for (int i = 0; i < values.length; i++) {
			if (values[i] != null) {
				values[i].write();
				System.out.print(" ");

			}
		}
	}
}
