module NullObject_exerice {
}