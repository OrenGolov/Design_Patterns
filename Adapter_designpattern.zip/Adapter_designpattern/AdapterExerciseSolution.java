package Adapter_designpattern;


	class Square {
		public int side;
		
		public Square (int side){
			this.side=side;
		}
	}
	
	
	interface Rectangle{
		int getWidth();
		int getHeight();
		default int getArea(){
			return getWidth() * getHeight();
		}
	}
	
	class SquareToRectangleAdapter implements Rectangle{
		Square adapter;
		
		public SquareToRectangleAdapter (Square square) {
			adapter = square;
		}

		@Override
		public int getWidth() {
			return adapter.side;
		}

		@Override
		public int getHeight() {
			return adapter.side;
		}
	}
	
	public class AdapterExerciseSolution {
	public static void main(String[] args) {
		Square s1 = new Square(6);
		SquareToRectangleAdapter squareToRectangle = new SquareToRectangleAdapter(s1);
		System.out.println(squareToRectangle.getArea());
		}
}
	


