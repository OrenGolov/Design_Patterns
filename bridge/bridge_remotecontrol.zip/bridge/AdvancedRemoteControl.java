package remotecontrol.bridge;

public class AdvancedRemoteControl extends RemoteControl {

	public AdvancedRemoteControl(Device device) {
		super(device);
	}

	public void setChanel(int val) {
		device.setChanel(val);
	}

	public void mute() {
		device.mute();
	}

}
