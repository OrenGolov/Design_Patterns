package remotecontrol.bridge;

public class TV implements Device {
	private int chanel;
	private int volume;

	public TV() {
		this.chanel = 1;
		this.volume = 30;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}

	public int getChanel() {
		return chanel;
	}

	@Override
	public void plusVolume() {
		volume++;
	}

	@Override
	public void minusVolume() {
		volume--;
	}

	@Override
	public void plusChanel() {
		chanel++;
	}

	@Override
	public void minusChanel() {
		chanel--;
	}

	@Override
	public void setChanel(int val) {
		setChanel(val);
	}

	@Override
	public void mute() {
		setVolume(0);
	}

}
