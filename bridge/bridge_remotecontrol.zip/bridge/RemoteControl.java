package remotecontrol.bridge;

public class RemoteControl extends ARemoteControl {

	public RemoteControl(Device device) {
		super(device);
	}

	public void plusVolume() {
		device.plusVolume();
	}

	public void minusVolume() {
		device.minusVolume();
	}

	public void plusChanel() {
		device.plusChanel();
	}

	public void minusChanel() {
		device.minusChanel();
	}

}
