package remotecontrol.bridge;

public interface Device {
	void plusVolume();
	void minusVolume();
	void plusChanel();
	void minusChanel();
	
	void setChanel(int val);
	void mute();
}
