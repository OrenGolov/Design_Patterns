package remotecontrol.bridge;

public abstract class ARemoteControl {
	protected Device device;

	public ARemoteControl(Device device) {
		this.device = device;
	}
}