
public abstract class Square extends Shape{

	@Override
	void draw() {
		System.out.println("Drawing square...");
	}

}
