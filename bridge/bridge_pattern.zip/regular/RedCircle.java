
public class RedCircle extends Circle{

	@Override
	void draw() {
		super.draw();
		System.out.println("Filling in red color...");
	}

}
