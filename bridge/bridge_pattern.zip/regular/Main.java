
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle redCircle = new RedCircle();
		Square greenSquare = new GreenSquare();
		
		redCircle.draw();
		greenSquare.draw();
	}

}
