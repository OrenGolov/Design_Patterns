
public class GreenRectangle extends Rectangle{

	@Override
	void draw() {
		super.draw();
		System.out.println("Filling in green color...");
	}

}
