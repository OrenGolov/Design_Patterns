
public class RedRectangle extends Rectangle{

	@Override
	void draw() {
		super.draw();
		System.out.println("Filling in red color...");
	}

}
