
public class GreenCircle extends Circle{

	@Override
	void draw() {
		super.draw();
		System.out.println("Filling in green color...");
	}

}
