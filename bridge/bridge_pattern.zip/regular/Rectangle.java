
public abstract class Rectangle extends Shape{

	@Override
	void draw() {
		System.out.println("Drawing rectangle...");
	}

}
