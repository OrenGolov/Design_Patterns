
public class GreenSquare extends Square{

	@Override
	void draw() {
		super.draw();
		System.out.println("Filling in green color...");
	}

}
