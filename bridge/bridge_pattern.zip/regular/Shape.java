import javafx.scene.paint.Color;

public abstract class Shape {
//	protected Color color;
	abstract void draw();
}
