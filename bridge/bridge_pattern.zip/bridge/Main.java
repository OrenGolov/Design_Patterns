package bridge.shape;

public class Main {

	public static void main(String[] args) {
		Circle redCircle = new Circle(new RedFill());
		Square greenSquare = new Square(new GreenFill());
		
		redCircle.draw();
		greenSquare.draw();
	}

}
