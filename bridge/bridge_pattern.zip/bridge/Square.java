package bridge.shape;

public class Square extends Shape{

	public Square(Fillable fillable) {
		super(fillable);
	}

	@Override
	void draw() {
		System.out.println("Drawing square...");
		fillable.fillIn();
	}

}
