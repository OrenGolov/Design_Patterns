package bridge.shape;

public class RedFill implements Fillable{

	@Override
	public void fillIn() {
		System.out.println("Filling in red color...");		
	}

}
