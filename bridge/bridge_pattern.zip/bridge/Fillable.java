package bridge.shape;

public interface Fillable {
	void fillIn();
}

