package bridge.shape;

public class Circle extends Shape{

	public Circle(Fillable fillable) {
		super(fillable);
		// TODO Auto-generated constructor stub
	}

	@Override
	void draw() {
		System.out.println("Drawing circle...");
		fillable.fillIn();

	}

}
