package bridge.shape;

public class GreenFill implements Fillable{

	@Override
	public void fillIn() {
		System.out.println("Filling in green color...");		
	}

}
