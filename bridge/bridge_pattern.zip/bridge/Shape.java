package bridge.shape;
import javafx.scene.paint.Color;

public abstract class Shape {
	protected Fillable fillable;
	
	public Shape(Fillable fillable) {
		this.fillable = fillable;
	}
	abstract void draw();
}
