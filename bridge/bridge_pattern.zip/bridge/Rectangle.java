package bridge.shape;

public abstract class Rectangle extends Shape{

	public Rectangle(Fillable fillable) {
		super(fillable);
		// TODO Auto-generated constructor stub
	}

	@Override
	void draw() {
		System.out.println("Drawing rectangle...");
		fillable.fillIn();
	}

}
