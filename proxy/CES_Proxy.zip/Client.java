public class Client {
	public static void main(String[] args) {
		Internet internet = new AfekaInternet();
		try {
			internet.connectTo("afeka.ac.il");
			internet.connectTo("abc.com");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		internet = new ProxyAfekaInternet();
		try {
			internet.connectTo("afeka.ac.il");
			internet.connectTo("abc.com");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}