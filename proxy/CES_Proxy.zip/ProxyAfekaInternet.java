import java.util.InputMismatchException;


public class ProxyAfekaInternet extends AfekaInternet {
	private String bannedSite = "abc.com";
	
	@Override
	public void connectTo(String serverhost) throws Exception{
		if (bannedSite.equals(serverhost)){
			throw new Exception("Access Denided");
		}
		super.connectTo(serverhost);
	}
}