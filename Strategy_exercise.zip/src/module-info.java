module Strategy_exercise {
}