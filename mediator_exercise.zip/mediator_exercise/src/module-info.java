module mediator_exercise {
	requires javafx.base;
}