module Factory_designpattern {
}